package com.raj.weathertodo.utils

interface uploadListner {
    fun onResponse(data : String)
}