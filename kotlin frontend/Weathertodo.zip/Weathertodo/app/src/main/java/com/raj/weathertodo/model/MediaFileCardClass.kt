package com.raj.weathertodo.model

class MediaFileCardClass(var title : String, var fileUri : String, var fileType : Int) { //0 = photo, 1 = video, 2 = audio
}