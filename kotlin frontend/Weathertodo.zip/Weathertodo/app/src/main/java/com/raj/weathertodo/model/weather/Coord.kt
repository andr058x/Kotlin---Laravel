package com.raj.weathertodo.model.weather

data class Coord(
    val lat: Double,
    val lon: Double
)