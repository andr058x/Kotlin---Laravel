package com.raj.weathertodo.model.weather

data class Clouds(
    val all: Int
)