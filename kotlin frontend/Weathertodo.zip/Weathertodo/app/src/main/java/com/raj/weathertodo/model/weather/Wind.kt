package com.raj.weathertodo.model.weather

data class Wind(
    val deg: Int,
    val speed: Double
)